package br.com.leandrosnazareth.pdvapi.dto;

import lombok.Data;

@Data
public class UserDTO {

    private String username;
    private String name;
}