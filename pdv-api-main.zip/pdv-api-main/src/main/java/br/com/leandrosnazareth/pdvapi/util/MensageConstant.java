package br.com.leandrosnazareth.pdvapi.util;

public final class MensageConstant {

    public static final String PRODUTO_NAO_ENCONTRADO = "Não foi encontrado o produto: ";

}
